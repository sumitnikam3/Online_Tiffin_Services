import express from 'express';
// import { addFood } from '../controllers/foodController.js';
import multer from 'multer'; //image control
import path from 'path';
import { addFood, listFood } from '../controllers/foodController.js';

const foodRouter = express.Router();

// To store image

// const storage = multer.diskStorage({
//     destination: "uploads",
//     filename: (req, file, cb) => {
//         return cb(null, `${Date.now()} ${file.originalname}`);
//     }
// })
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'uploads/'); // Directory to save images
    },
    filename: function (req, file, cb) {
        cb(null, Date.now() + '-' + file.originalname); // Save with unique name
    }
});

const upload = multer({ storage: storage });

foodRouter.post("/add",upload.single("image"),addFood);
foodRouter.get("/list", listFood);


export default foodRouter;