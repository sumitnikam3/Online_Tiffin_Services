import express from "express";
import cors from "cors";
import { connectDB } from "./configuration/Database.js";
import foodRouter from "./routes/foodRoute.js";

//Configuration
const app = express();
const PORT = 7400;
//MW
app.use(express.json());
app.use(cors());

//DB connection

connectDB();

//api endpoints

app.use("/api/food", foodRouter);

app.get("/", (req, res) => {
    res.send("API STRATED");
});

app.listen(PORT, () => {
    console.log(`Server Stated ${PORT}`);
});

